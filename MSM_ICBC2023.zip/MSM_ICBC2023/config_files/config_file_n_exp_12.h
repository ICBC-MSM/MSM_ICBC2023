/*
n = 2**12
*/

const int N_EXP = 12; 
const size_t N_POINTS = (size_t) 1<< N_EXP; 

// parameters for q/5 ICBC23
constexpr int EXPONENT_OF_q = 11;
constexpr int q_RADIX = (int) (1 << EXPONENT_OF_q);
constexpr int h_LEN_SCALAR = 24;
constexpr int a_LEADING_TERM = 3;
constexpr int d_MAX_DIFF = 6;
constexpr int B_SIZE = 427;


// parameters for q/5 ICBC23 GLV
constexpr int EXPONENT_OF_q_GLV = 12;
constexpr int q_RADIX_GLV = (int) (1 << EXPONENT_OF_q_GLV);
constexpr int h_LEN_SCALAR_GLV = 11;
constexpr int a_LEADING_TERM_GLV = 172;
constexpr int d_MAX_DIFF_GLV = 6;
constexpr int B_SIZE_GLV = 870;
