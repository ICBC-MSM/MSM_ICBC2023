/*
n = 2**21
*/

const int N_EXP = 21; 
const size_t N_POINTS = (size_t) 1<< N_EXP; 

// parameters for q/5 ICBC23
constexpr int EXPONENT_OF_q = 20;
constexpr int q_RADIX = (int) (1 << EXPONENT_OF_q);
constexpr int h_LEN_SCALAR =  13;
constexpr int a_LEADING_TERM = 29677;
constexpr int d_MAX_DIFF = 6;
constexpr int B_SIZE = 220931;

// parameters for q/5 ICBC23 GLV
constexpr int EXPONENT_OF_q_GLV = 19;
constexpr int q_RADIX_GLV = (int) (1 << EXPONENT_OF_q_GLV);
constexpr int h_LEN_SCALAR_GLV = 7;
constexpr int a_LEADING_TERM_GLV = 11025;
constexpr int d_MAX_DIFF_GLV = 6;
constexpr int B_SIZE_GLV = 110143;

