/***----***
 
Compile with: g++ -std=c++17 -o main_test -g -O2 main_p2.cpp libblst.a 

If segmentation fault occurs, possibly it can be tentatively circumvented by using the following code in command line to unleash the stack restriction:

ulimit -s unlimited

All functions must be invoked after init_xx().

-- Authors. Oct, 2022.

***----***/


#include "bindings/blst.h"

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <random>
#include <iomanip>

#include <set>
#include <array>
// don't use namespace std, there is a uint_8 and byte definition that are not compatible with std.


/***----***
Define configuration
***----***/
#include "config_files/config_file_n_exp_12.h" //define configuration in a seperate file.
bool TEST_PIPPENGER_Q_OVER_5_ICBC23 = 1; // Due to the momory size limitation, some time we need to switch off one of the test.


/***----***
A) Define global variables and their initializations
***----***/

digit_decomposition* DIGIT_CONVERSION_HASH_TABLE;
digit_decomposition* DIGIT_CONVERSION_HASH_TABLE_GLV;

#include "auxiliaryfunc.h"

std::set<int> MULTI_SET = {1, 2, 3};
int* BUCKET_SET;
int* BUCKET_VALUE_TO_ITS_INDEX; 

std::set<int> MULTI_SET_GLV = {1, 2, 3};
int* BUCKET_SET_GLV;
int* BUCKET_VALUE_TO_ITS_INDEX_GLV; 

blst_p2_affine* FIX_POINTS_LIST;
blst_p2_affine* PRECOMPUTATION_POINTS_LIST_3n;


void init_fix_point_list(){

    // Initialize FIX_POINTS_LIST
    FIX_POINTS_LIST = new blst_p2_affine [N_POINTS];
    blst_p2 tmp_P, tmp2_P = *blst_p2_generator();
    blst_p2_affine tmp_P_affine;

    for(size_t i = 0; i < N_POINTS; ++i){
            blst_p2_double(&tmp_P, &tmp2_P);
            tmp2_P = tmp_P;  
            blst_p2_to_affine(&tmp_P_affine, &tmp_P);
            (FIX_POINTS_LIST)[i] = tmp_P_affine;
        }
    std::cout<< "FIX_POINTS_LIST Generated" <<std::endl;
}

void free_init_fix_point_list(){
    delete[] FIX_POINTS_LIST;
}

blst_p2_affine single_scalar_multiplication(uint256_t scalar, const blst_p2_affine Q){

    blst_p2_affine aret; 
    blst_p2 ret = {0,1,0}; // ret = INFINITY; 

    blst_p2 xyzQ;
    blst_p2_from_affine(&xyzQ, &Q);

    while (scalar > 0){
        if ( scalar.data[0] & 1 ){
            blst_p2_add_or_double(&ret, &ret, &xyzQ);
        }
        
        blst_p2_add_or_double(&xyzQ, &xyzQ, &xyzQ);    // tested. No need to use temp variable.
        scalar = scalar >> 1; 
    }

    blst_p2_to_affine(&aret, &ret);
    return aret;
} 


void init_pippenger_ICBC23_q_over_5(){
    //Initialize BUCKET_SET and BUCKET_VALUE_TO_ITS_INDEX 
    BUCKET_SET = new int[B_SIZE];
    construct_bucket_set(BUCKET_SET, q_RADIX, a_LEADING_TERM);
    std::cout<< "BUCKET_SET constructed. The size of BUCKET_SET is: " << B_SIZE << std::endl;

    BUCKET_VALUE_TO_ITS_INDEX = new int[q_RADIX/2 +1];
    for(size_t i = 0; i < B_SIZE; ++i){
        BUCKET_VALUE_TO_ITS_INDEX[BUCKET_SET[i]] = i;
    }
    
    // Initialize  DIGIT_CONVERSION_HASH_TABLE;
    DIGIT_CONVERSION_HASH_TABLE = new digit_decomposition[q_RADIX+1];
    for(int m: MULTI_SET){
        for (int i = 0; i < B_SIZE; ++i){
            int b = BUCKET_SET[i];
            if (m*b <= q_RADIX) DIGIT_CONVERSION_HASH_TABLE[q_RADIX - m*b] = {m,b,1};
        }
    }
    for(int m: MULTI_SET){
        for (int i = 0; i < B_SIZE; ++i){
            int b = BUCKET_SET[i];
            if (m*b <= q_RADIX) DIGIT_CONVERSION_HASH_TABLE[m*b] = {m,b,0};
        }
    }
    std::cout<< "DIGIT_CONVERSION_HASH_TABLE constructed." <<std::endl;
    
    // ### Initialize the precomputation ###
   PRECOMPUTATION_POINTS_LIST_3n = new blst_p2_affine [3*N_POINTS];

    auto st = std::chrono::steady_clock::now();

    for(int i = 0; i< N_POINTS; ++i){
        blst_p2_affine Qi = FIX_POINTS_LIST[i];
        for(int m = 1; m <=3; ++m){
            size_t idx_i_m =  3*i + m-1;  
            if(m==1) PRECOMPUTATION_POINTS_LIST_3n[idx_i_m]  = Qi;
            else{PRECOMPUTATION_POINTS_LIST_3n[idx_i_m] = single_scalar_multiplication(m, Qi);}
        }
    }
    auto ed = std::chrono::steady_clock::now();   

    std::chrono::microseconds diff = std::chrono::duration_cast<std::chrono::microseconds>(ed -st);
    std::cout<< "PRECOMPUTATION_POINTS_LIST_3n SUCCESSFULLY CONSTRUCTED" << std::endl;
    std::cout << "PRECOMPUTATION Wall clock time elapse is: " << diff.count() << " us "<< std::endl;
}

void free_init_pippenger_ICBC23_q_over_5(){

    delete[] PRECOMPUTATION_POINTS_LIST_3n;
    delete[] DIGIT_CONVERSION_HASH_TABLE;
    delete[] BUCKET_VALUE_TO_ITS_INDEX;
    delete[] BUCKET_SET;
}

void init_pippenger_ICBC23_q_over_5_GLV(){
    //Initialize BUCKET_SET and BUCKET_VALUE_TO_ITS_INDEX 
    BUCKET_SET_GLV = new int[B_SIZE_GLV];
    construct_bucket_set(BUCKET_SET_GLV, q_RADIX_GLV, a_LEADING_TERM_GLV);
    std::cout<< "BUCKET_SET_GLV constructed. The size of BUCKET_SET_GLV is: " << B_SIZE_GLV << std::endl;

    BUCKET_VALUE_TO_ITS_INDEX_GLV = new int[q_RADIX_GLV/2 +1];
    for(size_t i = 0; i < B_SIZE_GLV; ++i){
        BUCKET_VALUE_TO_ITS_INDEX_GLV[BUCKET_SET_GLV[i]] = i;
    }
    
    // Initialize  DIGIT_CONVERSION_HASH_TABLE;
    DIGIT_CONVERSION_HASH_TABLE_GLV = new digit_decomposition[q_RADIX_GLV+1];
    for(int m: MULTI_SET_GLV){
        for (int i = 0; i < B_SIZE_GLV; ++i){
            int b = BUCKET_SET_GLV[i];
            if (m*b <= q_RADIX_GLV) DIGIT_CONVERSION_HASH_TABLE_GLV[q_RADIX_GLV - m*b] = {m,b,1};
        }
    }
    for(int m: MULTI_SET_GLV){
        for (int i = 0; i < B_SIZE_GLV; ++i){
            int b = BUCKET_SET_GLV[i];
            if (m*b <= q_RADIX_GLV) DIGIT_CONVERSION_HASH_TABLE_GLV[m*b] = {m,b,0};
        }
    }
    std::cout<< "DIGIT_CONVERSION_HASH_TABLE_GLV constructed." <<std::endl;
    
    // ### The precomputation is the same as non-GLV method ###
}

void free_init_pippenger_ICBC23_q_over_5_GLV(){

    delete[] DIGIT_CONVERSION_HASH_TABLE_GLV;
    delete[] BUCKET_VALUE_TO_ITS_INDEX_GLV;
    delete[] BUCKET_SET_GLV;
}


/***----***
B) Define pippenger's bucket method and its variants
***----***/

blst_p2_affine pippenger_variant_q_over_5_ICBC23(uint256_t scalars_array[]){
    
    std::array<std::array< int, 2>, h_LEN_SCALAR> ret_MB_expr;

    uint64_t npoints = N_POINTS*h_LEN_SCALAR;

    int* scalars;
    scalars = new int [npoints+1]; // add 1 slot redundancy for prefetch, 20221010 very important
    scalars[npoints] = 0;  

    unsigned char* booth_signs; // it acts as a bool type
    booth_signs = new unsigned char [npoints];

    blst_p2_affine** points_ptr;
    points_ptr = new blst_p2_affine* [npoints];

    for(int i = 0; i< N_POINTS; ++i){
        
        trans_uint256_t_to_MB_radixq_expr(ret_MB_expr, scalars_array[i]);
        // print(ret_MB_expr);
        for(int j = 0; j< h_LEN_SCALAR; ++j){
            size_t idx = N_POINTS*j + i;
            
            scalars[idx]  = ret_MB_expr[j][1];

            int m = ret_MB_expr[j][0];

            if (m> 0) {
                points_ptr[idx] = PRECOMPUTATION_POINTS_LIST_3n +  3*i+ m-1;
                booth_signs[idx] = 0; 
            }
            else{
                points_ptr[idx] = PRECOMPUTATION_POINTS_LIST_3n + 3*i - m-1; // This is vital, which caused a severe bug.
                booth_signs[idx] = 1; 
            }  
        }
    }

    blst_p2 ret = {0, 0, 0}; // Mont coordinates

    blst_p2xyzz* buckets;
    buckets = new blst_p2xyzz [B_SIZE];

    for(int j = h_LEN_SCALAR - 1; j>= 0; --j){

        int* tile_scalars = scalars + N_POINTS*j;
        blst_p2_affine** tile_points_ptr = points_ptr + N_POINTS*j;
        unsigned char* tile_booth_signs = booth_signs + N_POINTS*j; 

        blst_p2 tile_ret = {0, 0, 0};

        blst_p2_tile_pippenger_d_CHES(&tile_ret, tile_points_ptr, N_POINTS, tile_scalars, tile_booth_signs,\
                                         buckets, BUCKET_SET, BUCKET_VALUE_TO_ITS_INDEX , B_SIZE, d_MAX_DIFF);
        
        blst_p2_add_or_double(&ret, &ret, &tile_ret);

        if(j != 0){
            for (int i = 0; i < EXPONENT_OF_q; ++i) blst_p2_double(&ret, &ret);
        } 
    }

    delete[] buckets;
    delete[] points_ptr;
    delete[] booth_signs;  
    delete[] scalars;  

    blst_p2_affine res_affine;
    blst_p2_to_affine( &res_affine, &ret);

    return res_affine;
}


blst_p2_affine pippenger_variant_q_over_5_ICBC23_GLV(uint256_t scalars_array[]){
    
    //GLV endmorphism: lambda(x,y) = (beta x, y)
    const uint256_t LAMBDA_GLV = uint256_t{0xffffffff, 0xac45a4010001a402, 0, 0};
    blst_fp BETA_GLV_fp;
    //  (beta1<<384)%p, this is the correct one considering the Montgomery multiplication

    BETA_GLV_fp.l[0] =  0x30f1361b798a64e8;
    BETA_GLV_fp.l[1] =  0xf3b8ddab7ece5a2a;
    BETA_GLV_fp.l[2] =  0x16a8ca3ac61577f7;
    BETA_GLV_fp.l[3] =  0xc26a2ff874fd029b;
    BETA_GLV_fp.l[4] =  0x3636b76660701c6e;
    BETA_GLV_fp.l[5] =  0x051ba4ab241b6160;    

    blst_fp2 BETA_GLV = {BETA_GLV_fp, 0};
    // g2_GLV = ((lamda + 1) << 256)/r_subgrouporder
    const uint256_t g2_GLV = uint256_t{0x63f6e522f6cfee30, 0x7c6becf1e01faadd, 0x1, 0x0};

    uint64_t npoints = 2*N_POINTS*h_LEN_SCALAR_GLV;

    int* scalars;
    scalars = new int [npoints+1]; // add 1 slot redundancy for prefetch, 20221010 very important
    scalars[npoints] = 0;  

    unsigned char* booth_signs; // it acts as a bool type
    booth_signs = new unsigned char [npoints];

    blst_p2_affine** points_ptr;
    points_ptr = new blst_p2_affine* [npoints];

    std::array<std::array< int, 2>, h_LEN_SCALAR_GLV> ret_MB_expr;

    for(int i = 0; i< N_POINTS; ++i){
        
        uint256_t q = scalars_array[i].mul_extended(g2_GLV).second;
        uint256_t r = scalars_array[i] - LAMBDA_GLV*q;

        if(r > LAMBDA_GLV){
            ++q;
            r -= LAMBDA_GLV;
        }

        // uint256_t check_eq = scalars_array[i] - q*LAMBDA_GLV - r ;
        // if( check_eq != 0 || q > (uint256_t(1)<<128) || r> (uint256_t(1)<<128)){
        //     std::cout << " EEEEEEERROR" << std::endl;
        // }
        
        // uint256_t q_1 = scalars_array[i]/(LAMBDA_GLV);
        // uint256_t r_1 = scalars_array[i]%(LAMBDA_GLV);
        // if(q != q_1 || r != r_1){
        //     std::cout << " awful!!: "<< i << std::endl;
        //     std::cout << " q: "<< (q_1 - q) << std::endl;
        //     std::cout << " r: "<< r - r_1 << std::endl;
        // }

        trans_uint128_t_to_MB_radixq_expr_GLV(ret_MB_expr, r);
        // print(ret_MB_expr);
        for(int j = 0; j< h_LEN_SCALAR_GLV; ++j){
            size_t idx = 2*N_POINTS*j + i;
            scalars[idx]  = ret_MB_expr[j][1];

            int m = ret_MB_expr[j][0];

            if (m> 0) {
                points_ptr[idx] = PRECOMPUTATION_POINTS_LIST_3n +  3*i+ m-1;
                booth_signs[idx] = 0; 
            }
            else{
                points_ptr[idx] = PRECOMPUTATION_POINTS_LIST_3n + 3*i - m-1; // This is vital, which caused a severe bug.
                booth_signs[idx] = 1; 
            }  
        }

        trans_uint128_t_to_MB_radixq_expr_GLV(ret_MB_expr, q);
        // print(ret_MB_expr);
        for(int j = 0; j< h_LEN_SCALAR_GLV; ++j){
            size_t idx = 2*N_POINTS*j + N_POINTS + i;
            scalars[idx]  = ret_MB_expr[j][1];

            int m = ret_MB_expr[j][0];

            if (m> 0) {
                points_ptr[idx] = PRECOMPUTATION_POINTS_LIST_3n +  3*i+ m-1;
                booth_signs[idx] = 0; 
            }
            else{
                points_ptr[idx] = PRECOMPUTATION_POINTS_LIST_3n + 3*i - m-1; // This is vital, which caused a severe bug.
                booth_signs[idx] = 1; 
            }  
        }


    }

    blst_p2 ret = {0, 0, 0}; // Mont coordinates

    blst_p2_affine* TMP_POINTS_GLV;
    TMP_POINTS_GLV = new blst_p2_affine [N_POINTS];
    blst_p2xyzz* buckets;
    buckets = new blst_p2xyzz [B_SIZE_GLV];

    for(int j = h_LEN_SCALAR_GLV - 1; j>= 0; --j){

        int* tile_scalars = scalars + 2*N_POINTS*j;
        blst_p2_affine** tile_points_ptr = points_ptr + 2*N_POINTS*j;
        unsigned char* tile_booth_signs = booth_signs + 2*N_POINTS*j; 

        blst_fp2 newPx;
        for(int i = 0; i< N_POINTS; ++i){
            blst_p2_affine tmp_P = *(tile_points_ptr[N_POINTS + i]);
            blst_fp2_mul(&newPx, &BETA_GLV, &tmp_P.x);
            TMP_POINTS_GLV[i] = blst_p2_affine{newPx, tmp_P.y};
            tile_points_ptr[N_POINTS + i] = & TMP_POINTS_GLV[i];
        }

        blst_p2 tile_ret = {0, 0, 0};

        blst_p2_tile_pippenger_d_CHES(&tile_ret, tile_points_ptr, 2*N_POINTS, tile_scalars, tile_booth_signs,\
                                         buckets, BUCKET_SET_GLV, BUCKET_VALUE_TO_ITS_INDEX_GLV , B_SIZE_GLV, d_MAX_DIFF_GLV);
        
        blst_p2_add_or_double(&ret, &ret, &tile_ret);

        if(j != 0){
            for (int i = 0; i < EXPONENT_OF_q_GLV; ++i) blst_p2_double(&ret, &ret);
        }
    }

    delete[] TMP_POINTS_GLV;
    delete[] buckets;
    delete[] points_ptr;
    delete[] booth_signs;  
    delete[] scalars;  

    blst_p2_affine res_affine;
    blst_p2_to_affine( &res_affine, &ret);

    return res_affine;
}


blst_p2_affine pippenger_variant_q_over_5_ICBC23_GLV_preparation_timing(uint256_t scalars_array[]){
    
    //GLV endmorphism: lambda(x,y) = (beta x, y)
    const uint256_t LAMBDA_GLV = uint256_t{0xffffffff, 0xac45a4010001a402, 0, 0};
    blst_fp BETA_GLV_fp;
    //  (beta1<<384)%p, this is the correct one considering the Montgomery multiplication

    BETA_GLV_fp.l[0] =  0x30f1361b798a64e8;
    BETA_GLV_fp.l[1] =  0xf3b8ddab7ece5a2a;
    BETA_GLV_fp.l[2] =  0x16a8ca3ac61577f7;
    BETA_GLV_fp.l[3] =  0xc26a2ff874fd029b;
    BETA_GLV_fp.l[4] =  0x3636b76660701c6e;
    BETA_GLV_fp.l[5] =  0x051ba4ab241b6160;    

    blst_fp2 BETA_GLV = {BETA_GLV_fp, 0};
    // g2_GLV = ((lamda + 1) << 256)/r_subgrouporder
    const uint256_t g2_GLV = uint256_t{0x63f6e522f6cfee30, 0x7c6becf1e01faadd, 0x1, 0x0};

    uint64_t npoints = 2*N_POINTS*h_LEN_SCALAR_GLV;

    int* scalars;
    scalars = new int [npoints+1]; // add 1 slot redundancy for prefetch, 20221010 very important
    scalars[npoints] = 0;  

    unsigned char* booth_signs; // it acts as a bool type
    booth_signs = new unsigned char [npoints];

    blst_p2_affine** points_ptr;
    points_ptr = new blst_p2_affine* [npoints];

    std::array<std::array< int, 2>, h_LEN_SCALAR_GLV> ret_MB_expr;

    for(int i = 0; i< N_POINTS; ++i){
        
        uint256_t q = scalars_array[i].mul_extended(g2_GLV).second;
        uint256_t r = scalars_array[i] - LAMBDA_GLV*q;

        if(r > LAMBDA_GLV){
            ++q;
            r -= LAMBDA_GLV;
        }

        trans_uint128_t_to_MB_radixq_expr_GLV(ret_MB_expr, r);
        // print(ret_MB_expr);
        for(int j = 0; j< h_LEN_SCALAR_GLV; ++j){
            size_t idx = 2*N_POINTS*j + i;
            scalars[idx]  = ret_MB_expr[j][1];

            int m = ret_MB_expr[j][0];

            if (m> 0) {
                points_ptr[idx] = PRECOMPUTATION_POINTS_LIST_3n +  3*i+ m-1;
                booth_signs[idx] = 0; 
            }
            else{
                points_ptr[idx] = PRECOMPUTATION_POINTS_LIST_3n + 3*i - m-1; // This is vital, which caused a severe bug.
                booth_signs[idx] = 1; 
            }  
        }

        trans_uint128_t_to_MB_radixq_expr_GLV(ret_MB_expr, q);

        for(int j = 0; j< h_LEN_SCALAR_GLV; ++j){
            size_t idx = 2*N_POINTS*j + N_POINTS + i;
            scalars[idx]  = ret_MB_expr[j][1];

            int m = ret_MB_expr[j][0];

            if (m> 0) {
                points_ptr[idx] = PRECOMPUTATION_POINTS_LIST_3n +  3*i+ m-1;
                booth_signs[idx] = 0; 
            }
            else{
                points_ptr[idx] = PRECOMPUTATION_POINTS_LIST_3n + 3*i - m-1; // This is vital, which caused a severe bug.
                booth_signs[idx] = 1; 
            }  
        }


    }

    blst_p2 ret = {0, 0, 0}; // Mont coordinates

    delete[] points_ptr;
    delete[] booth_signs;  
    delete[] scalars;  

    blst_p2_affine res_affine;
    blst_p2_to_affine( &res_affine, &ret);

    return res_affine;
}


blst_p2_affine pippenger_blst_built_in(uint256_t scalars_array[]){

    blst_scalar* scalars;
    scalars = new blst_scalar [N_POINTS];

    uint8_t** scalars_ptr;
    scalars_ptr = new uint8_t* [N_POINTS];

    for(size_t i = 0; i < N_POINTS; ++i){
            blst_scalar_from_uint64( &scalars[i], scalars_array[i].data);
            scalars_ptr[i] = (scalars[i].b);
    }

    blst_p2_affine** points_ptr;
    points_ptr = new blst_p2_affine* [N_POINTS]; // points_ptr is an array of pointers that point to blst_p2_affine points.

    for(size_t i = 0; i < N_POINTS; ++i){
            points_ptr[i] = FIX_POINTS_LIST + i;
        }

    limb_t* SCRATCH;
    SCRATCH = new limb_t[blst_p2s_mult_pippenger_scratch_sizeof(N_POINTS)/sizeof(limb_t)];

    blst_p2 ret; // Mont coordinates
    size_t nbits = 255;

    blst_p2s_mult_pippenger(&ret, points_ptr, N_POINTS, scalars_ptr, nbits, SCRATCH);   

    delete[] SCRATCH;
    delete[] points_ptr;
    delete[] scalars_ptr;
    delete[] scalars;

    blst_p2_affine res_affine;
    blst_p2_to_affine( &res_affine, &ret);
    return res_affine;
}

void test_pippengers(){
    std::cout << "\nPIPPENGERS TEST OVER G2 for NPOINTS:  2**" << N_EXP << std::endl;

    size_t TEST_NUM;
    size_t LOOP_NUM;


    if(N_EXP <= 8){TEST_NUM = 5; LOOP_NUM = 40;}
    else if(N_EXP <= 12) {TEST_NUM = 5; LOOP_NUM = 20;}
    else if(N_EXP<= 15) {TEST_NUM = 3; LOOP_NUM = 10;}
    else if(N_EXP<= 18) {TEST_NUM = 1; LOOP_NUM = 5;}
    else if(N_EXP<= 22) {TEST_NUM = 1; LOOP_NUM = 3;}
    else {TEST_NUM = 1; LOOP_NUM = 1;}
    
    std::chrono::microseconds acc_t1, acc_t2, acc_t3, acc_t4, acc_t5, acc_conver_q_over_5, acc_conver_bgmw, diff, min_t12; // time accumulation
    acc_t1 = std::chrono::microseconds::zero();
    acc_t2 = std::chrono::microseconds::zero();
    acc_t3 = std::chrono::microseconds::zero();
    acc_t4 = std::chrono::microseconds::zero();
    acc_t5 = std::chrono::microseconds::zero();

    acc_conver_q_over_5 = std::chrono::microseconds::zero();
    acc_conver_bgmw = std::chrono::microseconds::zero();

    auto st = std::chrono::steady_clock::now();
    auto ed = std::chrono::steady_clock::now();   
    
    blst_p2_affine ret_P_affine_1, ret_P_affine_2, ret_P_affine_3, ret_P_affine_4, ret_P_affine_5;


    // Initialize SCALARS_ARRAY

    scalar_MB_expr ret_MB_expr;

    for( int idx = 1; idx <= TEST_NUM; ++idx){

        uint256_t* SCALARS_ARRAY;
        SCALARS_ARRAY = new uint256_t[N_POINTS];
        std::cout << "This is No." << idx << " SCALARS_ARRAY." << std::endl;
        for(size_t i = 0; i < N_POINTS; ++i){
            SCALARS_ARRAY[i] = random_scalar_less_than_r();
            // std::cout << SCALARS_ARRAY[i] << std::endl;
        }
        

        if(TEST_PIPPENGER_Q_OVER_5_ICBC23){
            /*nh + q/5 method */
            st = std::chrono::steady_clock::now();
            for(size_t i = 0; i< LOOP_NUM; ++i)
            {
                ret_P_affine_1 = pippenger_variant_q_over_5_ICBC23(SCALARS_ARRAY);
            }
            ed = std::chrono::steady_clock::now();   
            diff = std::chrono::duration_cast<std::chrono::microseconds>(ed - st);
            acc_t1 += diff;

            /* nh + q/5 method 2 */

            st = std::chrono::steady_clock::now();
            for(size_t i = 0; i< LOOP_NUM; ++i)
            {
                ret_P_affine_2 = pippenger_variant_q_over_5_ICBC23_GLV(SCALARS_ARRAY);
            }
            ed = std::chrono::steady_clock::now();   
            diff = std::chrono::duration_cast<std::chrono::microseconds>(ed - st);
            acc_t2 += diff;
        }


        /*blst pippenger h(n+q/2) method*/
        st = std::chrono::steady_clock::now();    
        for(size_t i = 0; i< LOOP_NUM; ++i) 
        {
            ret_P_affine_4 = pippenger_blst_built_in(SCALARS_ARRAY);
        }
        ed = std::chrono::steady_clock::now(); 
        diff = std::chrono::duration_cast<std::chrono::microseconds>(ed - st);
        acc_t4 += diff;

        /* preparation benchmark*/

        if(TEST_PIPPENGER_Q_OVER_5_ICBC23){ 
            st = std::chrono::steady_clock::now();
            for(int j=0; j< LOOP_NUM; ++j){
                pippenger_variant_q_over_5_ICBC23_GLV_preparation_timing(SCALARS_ARRAY);
            }
            ed = std::chrono::steady_clock::now();   
            diff = std::chrono::duration_cast<std::chrono::microseconds>(ed - st);
            acc_conver_q_over_5 += diff;
        }

        std::cout <<  "First scalar: " << SCALARS_ARRAY[0] << std::endl; 
        delete[] SCALARS_ARRAY;
    }

    if(TEST_PIPPENGER_Q_OVER_5_ICBC23){
        std::cout << "\n1. ICBC23 'nh+ q/5'. Wall clock time elapse is: " << std::dec << acc_t1.count()/(TEST_NUM*LOOP_NUM) << " us "<< std::endl;
        std::cout << ret_P_affine_1.x <<std::endl;
        std::cout << ret_P_affine_1.y <<std::endl;
        std::cout << std::endl;

        std::cout << "2. ICBC23 'nh+ q/5' GLV. Wall clock time elapse is: " << std::dec << acc_t2.count()/(TEST_NUM*LOOP_NUM) << " us "<< std::endl;
        std::cout << ret_P_affine_2.x <<std::endl;
        std::cout << ret_P_affine_2.y <<std::endl;
        std::cout << std::endl;
    }

    std::cout << "3. pippenger_blst_built_in. Wall clock time elapse is: " << std::dec << acc_t4.count()/(TEST_NUM*LOOP_NUM) << " us "<< std::endl;
    std::cout << ret_P_affine_4.x <<std::endl;
    std::cout << ret_P_affine_4.y <<std::endl;
    std::cout << std::endl; 

    min_t12 = (acc_t1> acc_t2)? acc_t2 : acc_t1; 


    if(TEST_PIPPENGER_Q_OVER_5_ICBC23){
    std::cout << "Improvement, blst ICBC23_q_over_5 vs pipp: " <<\
    std::fixed << std::setprecision(3) << 100*float(acc_t4.count() - acc_t1.count())/float(acc_t4.count()) << '%' <<std::endl;
    std::cout << "Improvement, blst ICBC23_q_over_5_GLV vs pipp: " <<\
    std::fixed << std::setprecision(3) << 100*float(acc_t4.count() - acc_t2.count())/float(acc_t4.count()) << '%' <<std::endl;
    }

    if(TEST_PIPPENGER_Q_OVER_5_ICBC23){
    std::cout << "\nICBC23_q_over_5_GLV preparation (scalar conversion) clock time elapse is: " <<\
    std::dec << acc_conver_q_over_5.count()/(TEST_NUM*LOOP_NUM) << " us"<< std::endl;
    std::cout << "It takes up what percentage of q_over_5 time: " << \
    std::fixed << std::setprecision(3) << 100*float(acc_conver_q_over_5.count())/float(min_t12.count()) << '%' <<std::endl;
    }
    std::cout << "\nTEST END" <<std::endl;  

    // std::cout << blst_p2_affine_in_g2(&FIX_POINTS_LIST[1]) <<std::endl;      
}


int main(){
 
    init_fix_point_list();
    if(TEST_PIPPENGER_Q_OVER_5_ICBC23){
        init_pippenger_ICBC23_q_over_5();
        init_pippenger_ICBC23_q_over_5_GLV();
    }
    
    // Test should be down between init_xx() and free_init_xx();
    test_pippengers();

    if(TEST_PIPPENGER_Q_OVER_5_ICBC23) {
        free_init_pippenger_ICBC23_q_over_5();
        free_init_pippenger_ICBC23_q_over_5_GLV();
    }
    free_init_fix_point_list();

    return 0;
}

